InitSQL module
==============

.. automodule:: InitSQL
   :members:
   :undoc-members:
   :show-inheritance:
