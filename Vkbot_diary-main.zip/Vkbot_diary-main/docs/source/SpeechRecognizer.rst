SpeechRecognizer module
=======================

.. automodule:: SpeechRecognizer
   :members:
   :undoc-members:
   :show-inheritance:
