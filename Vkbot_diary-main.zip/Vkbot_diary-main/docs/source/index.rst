.. Vkbot diary documentation master file, created by
   sphinx-quickstart on Mon Mar 29 16:57:35 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Добро пожаловать в документацию "Vkbot diary"!
==============================================

.. toctree::
   :maxdepth: 4
   :caption: Содержимое:

   modules


Индексы и таблицы
=================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
