Vkbot_diary
===========

.. toctree::
   :maxdepth: 4

   InitConfig
   InitDatabase
   InitSQL
   MySQLStorage
   SpeechRecognizer
   VkBotChat
   VkBotDiary
   VkBotFunctions
   VkBotParser
   VkBotStatus
