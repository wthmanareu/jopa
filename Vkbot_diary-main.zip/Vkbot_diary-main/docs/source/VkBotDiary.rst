VkBotDiary module
=================

.. automodule:: VkBotDiary
   :members:
   :undoc-members:
   :show-inheritance:
