InitConfig module
=================

.. automodule:: InitConfig
   :members:
   :undoc-members:
   :show-inheritance:
