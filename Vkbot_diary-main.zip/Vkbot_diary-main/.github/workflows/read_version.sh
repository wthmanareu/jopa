BOT_VERSION='0.4.0'
echo ::set-output name=SOURCE_TAG::$BOT_VERSION